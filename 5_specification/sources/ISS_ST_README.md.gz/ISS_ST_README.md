# 结构验收集 v1.1.0-rc1

修订日期：2026-10-08。原包：`structure_acceptance_v1.tar.gz`。

**用途**：检验陌生计算结构的自动参照、声明范围和平均作用测量。保留原来的7类结构、33个程序和全部kernel计算主体；修复规格区间及输出接口，纠正计分与执行前提。不是新的盲测，也不是对任意Triton程序的全覆盖证明。

**状态**：CPU回归已运行；GPU编译、设备执行与完整工具接入尚未运行。原答案文件没有交付给本修订者，没有读取、重建或编造它。旧答案哈希仅作历史记录，不能沿用作本版正式评分依据。出题方应按本版输出接口与协议重新核账、封存。

## 结构与边界

| 家族 | 结构 | 独立任务f |
|---|---|---|
| T1 | 带mask的多值Welford归约 | 分别返回每行mean与有偏variance |
| T2 | 包含式前缀scan | `y_i = sum_{j<=i}(x_j*s)` |
| T3 | 嵌套循环、分块乘加、末次归约 | 每行精确点积 |
| T4 | program_id决定的分支 | 两个预声明仿射公式 |
| T5 | 保存/读取 | 每行去均值；其中一项另列为竞争边界探针 |
| T6 | 两次启动的状态传递 | `x/sqrt(mean(x²)+eps)` |
| T7 | 多program浮点atomic_add | 精确行点积；实际执行顺序另作随机性记录 |

32个程序属于常规测量轨；1个含无同步跨program读取的程序属于隔离边界轨，默认不运行，不纳入有限均值成绩，但保留在33项覆盖分母。安全分轨见`manifest.json`，不能依据运行结果临时删题。

## 本版修改

1. T6改用整数平方根和有理数端点，最后进入binary64接口时继续向外转换。推导见`docs/reference_notes.md`。
2. T1直接返回`{"mean": mean, "variance": var}`，不再用`torch.stack`制造额外最终输出。其余程序统一返回`{"output": tensor}`。所有kernel计算主体不变。
3. 保留两项未激活变体，不根据是否检出来调输入；它们不能预设为必须检出的阳性。具体说明在`docs/issuer_notes.md`。
4. 原子程序每输入重复8次，统计单位仍是输入，而不是8次执行或元素。相同算法的重命名对不一律要求独立启动逐位相等。
5. 竞争程序默认隔离；不通过增加块内barrier假装解决跨program同步。
6. 删除源码里直接提示“与干净版本相同”的注释。已阅读原包的暴露事实仍须记录，不能据此恢复盲法。

## 运行

CPU依赖：Python 3.10+、NumPy、PyTorch。此处不需要Triton或GPU。

```bash
python tools/verify_package.py
PYTHONDONTWRITEBYTECODE=1 python -m unittest discover -s tests -v
python tools/make_bindings.py --out ../acceptance_v11_bindings --mode both
```

产生64份薄绑定（32个常规程序各模式A/B）。它们复用同一个输入、调用和规格适配器；不包含专属检测器。输出保持kernel写出的原始Tensor，不进行clone/stack/数值转换。固定运行路径后不要搬动本包，因为生成绑定记录了其绝对路径。

GPU环境中先运行编译/执行预检：

```bash
python tools/gpu_preflight.py --out ../runs/preflight_v11.json --timeout 180
```

这个脚本隔离每个普通程序，只记录编译运行状态、输出形状/位哈希和非有限值，不计算bias，不读答案。存在编译问题应记录并按协议处理，不能擅自改变算法以取得通过。正式测量复用生产统一入口和冻结统计层，种子、规则和并发处理按`PROTOCOL.md`与已完成的`RUN_FREEZE.template.json`。

## 能运行与能评分是两回事

- 现在可以运行CPU核对、GPU预检、来源/覆盖核验、冻结规则的测量。
- 正式标签评分之前，需要出题方审阅本版、完成GPU预检与新封存；不能拿旧哈希认证新成绩。
- G/f含义、全调用/单kernel范围、非零/等价两轴分开。
- 没有证据建立零均值的“干净程序”，不自动是数值阴性。
- 包含FP64参考值是交叉核验，不自动证明精确包含性。
- 计分分母保留拒绝、未建立、超时、非有限及边界程序；不得把“未检出”写成“没有bias”。

本包没有实现或替换`kernel_analyzer`。测试日志、数值证书和修改清单在`validation/`、`CHANGELOG.md`和`change_manifest.json`。
