# T6包围与输出边界

## 数学目标

输入元素及eps取实际接收到的有限浮点数的精确有理数值。对一行，

q = sum(x_i²)/D + eps > 0，y_i = x_i/sqrt(q)。

本版计算t=1/q，再包围sqrt(t)。所有加、乘、除在Fraction上精确完成。

设e=floor(log2(t))，选择s=bits-1-floor(e/2)，默认bits=192。将t*2^(2s)写成整数比N/D，

m = isqrt(floor(N/D))。

因m² <= N/D < (m+1)²，

m*2^(-s) <= sqrt(t) < (m+1)*2^(-s)。

若m²D=N，返回点区间；否则返回相邻两个有理数端点。正x乘端点保持次序，负x交换端点。代码每次检查整数及有理数证书。此论证不依赖Decimal工作上下文、libm平方根或“高精度结果应当很准”的假设。

## binary64接口

先把有理数转换为binary64，再将该浮点数精确转回有理数比较。下端若偏高，用nextafter向负无穷移动；上端若偏低，向正无穷移动。次正规、零和超范围显式处理。非有限端点不能用于声称高分辨率的有限均值测量。

形式上的包含性来自上面的整数不等式；测试用于验证实现，没有把有限回归叫作全域证明。该辅助函数不是任意GPU程序的正确性证明器。

## 输出与f/G区分

T1返回原始mean、variance两个Tensor，规格和FP64基线均以相同名字返回。不能先把捕获值堆叠，再将新Tensor当作原Triton输出。

其他家族用output键。spec给f，自动参照G仍由被测工具独立从编译表示生成。不能用同一份spec代替G，再宣称已做e_num/e_sem分解。

## 依据

- Python math.isqrt：非负整数平方根的向下精确整数值。https://docs.python.org/3/library/math.html#math.isqrt
- Python Fraction：有限浮点数的精确有理数表示。https://docs.python.org/3/library/fractions.html
- Decimal square-root的舍入规定，是旧实现不能靠context.rounding签发上下界的原因。https://speleotrove.com/decimal/daops.html#refsqrt
- atomic_add的原子性与同步scope不等于固定浮点累计顺序。https://triton-lang.org/main/python-api/generated/triton.language.atomic_add.html
- debug_barrier同步的是一个block，不是全网格。https://triton-lang.org/main/python-api/generated/triton.language.debug_barrier.html

来源读取：2026-10-08。本文整数推导为本次修订给出的说明，不主张新数学结果。
