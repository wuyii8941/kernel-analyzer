"""Deterministic inputs for the structure acceptance set v1.1-rc1. All runtime scalars are exactly representable in float32."""
import math
import torch

SHAPES = {"T1": dict(R=64, D=1536), "T2": dict(R=64, D=1024), "T3": dict(R=64, K=4096), "T4": dict(R=64, D=2048),
          "T5": dict(R=64, D=2048), "T6": dict(R=64, D=2048), "T7": dict(R=64, K=4096)}


def _gen(seed):
    g = torch.Generator(device="cpu"); g.manual_seed(int(seed)); return g


def make_inputs(family, seed, device="cuda"):
    g = _gen(seed); s = SHAPES[family]
    if family == "T1":
        x = torch.randn(s["R"], s["D"], generator=g, dtype=torch.float32) * 1.5 + 0.25
        return dict(x=x.to(device))
    if family == "T2":
        x = torch.randn(s["R"], s["D"], generator=g, dtype=torch.float32)
        return dict(x=x.to(device), s=0.75)
    if family == "T3":
        x = torch.randn(s["R"], s["K"], generator=g, dtype=torch.float32); w = torch.randn(s["K"], generator=g, dtype=torch.float32)
        return dict(x=x.to(device), w=w.to(device))
    if family == "T4":
        x = torch.randn(s["R"], s["D"], generator=g, dtype=torch.float32)
        return dict(x=x.to(device), split=37, alpha=1.25, beta=0.5, gamma=0.125)
    if family == "T5":
        x = torch.randn(s["R"], s["D"], generator=g, dtype=torch.float32) + 0.5
        return dict(x=x.to(device))
    if family == "T6":
        x = torch.randn(s["R"], s["D"], generator=g, dtype=torch.float32)
        return dict(x=x.to(device), eps=math.ldexp(1.0, -20))
    if family == "T7":
        x = torch.randn(s["R"], s["K"], generator=g, dtype=torch.float32); w = torch.randn(s["K"], generator=g, dtype=torch.float32)
        return dict(x=x.to(device), w=w.to(device))
    raise KeyError(family)
