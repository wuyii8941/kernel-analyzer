"""Independent task specifications, v1.1-rc1.

Target = the finite values actually passed at the input interface. Rationals are
exact. T6 returns rational interval pairs proved with integer square-root bounds.
Every result is a mapping of output name to nested values, matching launch().
This module does not import the tool under test or any candidate kernel.
"""
from fractions import Fraction as F
import math
try:
    from .exact_intervals import sqrt_interval
except ImportError:  # direct standalone helper use
    from exact_intervals import sqrt_interval


class SpecNotEstablished(ValueError):
    """Input or requested domain is outside the declared finite test contract."""


def _scalar(value):
    try:
        v = float(value)
    except (TypeError, ValueError, OverflowError) as exc:
        raise SpecNotEstablished('invalid scalar') from exc
    if not math.isfinite(v):
        raise SpecNotEstablished('non-finite input is outside this finite contract')
    return F(v)


def _rows(t):
    if getattr(t, 'ndim', None) != 2 or t.shape[0] < 1 or t.shape[1] < 1:
        raise SpecNotEstablished('expected a nonempty rank-2 tensor')
    if not t.is_floating_point():
        raise SpecNotEstablished('expected floating input, not an integer tensor')
    return [[_scalar(v) for v in row] for row in t.detach().cpu().double().tolist()]


def spec(family, inp, *, bits=192):
    rows = _rows(inp['x'])
    if family == 'T1':
        means, variances = [], []
        for row in rows:
            m = sum(row, F(0))/len(row)
            means.append(m)
            variances.append(sum(((v-m)**2 for v in row), F(0))/len(row))
        return {'mean': means, 'variance': variances}
    if family == 'T2':
        s = _scalar(inp['s']); out = []
        for row in rows:
            acc = F(0); one = []
            for v in row:
                acc += v*s; one.append(acc)
            out.append(one)
        return {'output': out}
    if family in ('T3', 'T7'):
        w_t = inp['w']
        if getattr(w_t, 'ndim', None) != 1 or len(w_t) != len(rows[0]):
            raise SpecNotEstablished('weight shape must exactly match the reduction axis')
        w = [_scalar(v) for v in w_t.detach().cpu().double().tolist()]
        return {'output': [sum((a*b for a,b in zip(row,w)), F(0)) for row in rows]}
    if family == 'T4':
        a,b,c = (_scalar(inp[k]) for k in ('alpha','beta','gamma'))
        split = inp['split']
        if isinstance(split, bool) or not isinstance(split, int) or not 0 <= split <= len(rows):
            raise SpecNotEstablished('split must be an integer in the row range')
        return {'output': [[v*a for v in row] if r < split else [v*b+c for v in row]
                           for r,row in enumerate(rows)]}
    if family == 'T5':
        out = []
        for row in rows:
            mean = sum(row,F(0))/len(row)
            out.append([v-mean for v in row])
        return {'output': out}
    if family == 'T6':
        eps = _scalar(inp['eps'])
        if eps <= 0:
            raise SpecNotEstablished('eps must be positive in this task contract')
        out = []
        for row in rows:
            q = sum((v*v for v in row),F(0))/len(row) + eps
            rlo,rhi = sqrt_interval(1/q,bits)
            out.append([(v*rlo,v*rhi) if v>=0 else (v*rhi,v*rlo) for v in row])
        return {'output': out}
    raise SpecNotEstablished('unknown task family: '+str(family))
